Copy on this folder your Ancient empire II JAR file, and rename it too: temp.jar

