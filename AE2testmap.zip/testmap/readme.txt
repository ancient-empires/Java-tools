
	=====================================
	Ancient Empires II - Map tester batch
	=====================================

This pack is made to test quickly a AE2 map from the AE2 map editor.



Installation and usage:
----------------------
* Unpack this archive content somewhere.

* Copy a AE2 game .jar file into the temp\ folder and rename it to: temp\temp.jar

* Run the map editor and press the [Run] button, then select the batch file: testmap.cmd



This pack containing 2 different emulators (you can also add your own by editing the .cmd file)
------------------------------------------
* Midp2Exe
* Java (need to be installed) + mpowerplayer (recommended if Java is installed)

By default, the first emulator is set (method=1)
If you want to change this, edit the testmap.cmd, at line: "set method=1" and change the 1 to 2



For more information about this pack, do not hesitate to read the others README.TXT files from this pack.
------------------------------------



Happy mapping :)


byblo.

