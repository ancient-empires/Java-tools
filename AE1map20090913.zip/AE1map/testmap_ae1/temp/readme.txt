Copy on this folder your Ancient empire JAR file, and rename it too: temp.jar

